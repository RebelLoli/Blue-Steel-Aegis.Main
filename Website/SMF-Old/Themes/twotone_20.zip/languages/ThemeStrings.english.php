<?php
// Version: 2.0; Themes

global $scripturl;

$txt['quicknav_but1'] = 'Quick Link1 -> Button Name';
$txt['quicknav_url1'] = 'Quick Link1 -> Button Url';
$txt['quicknav_but2'] = 'Quick Link2 -> Button Name';
$txt['quicknav_url2'] = 'Quick Link2 -> Button Url';
$txt['quicknav_but3'] = 'Quick Link3 -> Button Name';
$txt['quicknav_url3'] = 'Quick Link3 -> Button Url';
$txt['quicknav_but4'] = 'Quick Link4 -> Button Name';
$txt['quicknav_url4'] = 'Quick Link4 -> Button Url';
$txt['quicknav_but5'] = 'Quick Link5 -> Button Name';
$txt['quicknav_url5'] = 'Quick Link5 -> Button Url';
$txt['quicknavs_desc'] = 'Above links will be displayed in header';
$txt['facebook_url'] = 'Facebook URL';
$txt['twitter_url'] = 'Twitter URL';
$txt['googleplus_url'] = 'Google+ URL';
$txt['dribble_url'] = 'Dribble URL';
$txt['flickr_url'] = 'Flickr URL';
$txt['youtube_url'] = 'Youtube URL';
$txt['rss_url'] = 'RSS URL';

$txt['show_unread'] = 'Unread';
$txt['show_replies'] = 'Replies';
$txt['maintenance'] = 'Site in Maintenance!';
$txt['approval_member'] = 'Member Approvals';
$txt['open_reports'] = 'Open Reports';
$txt['forum_search'] = 'Search...';

?>